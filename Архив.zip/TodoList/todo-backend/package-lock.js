{
    "name": "todo-backend",
    "version": "1.0.0",
    "lockfileVersion": 3,
    "requires": true,
    "packages": {
      "": {
        "name": "todo-backend",
        "version": "1.0.0",
        "license": "ISC",
        "dependencies": {
          "body-parser": "^1.20.2",
          "cors": "^2.8.5",
          "express": "^4.18.2",
          "mongoose": "^8.0.3"
        }
      },
      "node_modules/@mongodb-js/saslprep": {
        "version": "1.1.1",
        "resolved": "https://registry.npmjs.org/@mongodb-js/saslprep/-/saslprep-1.1.1.tgz",
        "integrity": "sha512-t7c5K033joZZMspnHg/gWPE4kandgc2OxE74aYOtGKfgB9VPuVJPix0H6fhmm2erj5PBJ21mqcx34lpIGtUCsQ==",
        "dependencies": {
          "sparse-bitfield": "^3.0.3"
        }
      },
      "node_modules/@types/node": {
        "version": "20.10.5",
        "resolved": "https://registry.npmjs.org/@types/node/-/node-20.10.5.tgz",
        "integrity": "sha512-nNPsNE65wjMxEKI93yOP+NPGGBJz/PoN3kZsVLee0XMiJolxSekEVD8wRwBUBqkwc7UWop0edW50yrCQW4CyRw==",
        "dependencies": {
          "undici-types": "~5.26.4"
        }
      },
      "node_modules/@types/webidl-conversions": {
        "version": "7.0.3",
        "resolved": "https://registry.npmjs.org/@types/webidl-conversions/-/webidl-conversions-7.0.3.tgz",
        "integrity": "sha512-CiJJvcRtIgzadHCYXw7dqEnMNRjhGZlYK05Mj9OyktqV8uVT8fD2BFOB7S1uwBE3Kj2Z+4UyPmFw/Ixgw/LAlA=="
      },
      "node_modules/@types/whatwg-url": {
        "version": "8.2.2",
        "resolved": "https://registry.npmjs.org/@types/whatwg-url/-/whatwg-url-8.2.2.tgz",
        "integrity": "sha512-FtQu10RWgn3D9U4aazdwIE2yzphmTJREDqNdODHrbrZmmMqI0vMheC/6NE/J1Yveaj8H+ela+YwWTjq5PGmuhA==",
        "dependencies": {
          "@types/node": "*",
          "@types/webidl-conversions": "*"
        }
      },
      "node_modules/accepts": {
        "version": "1.3.8",
        "resolved": "https://registry.npmjs.org/accepts/-/accepts-1.3.8.tgz",
        "integrity": "sha512-PYAthTa2m2VKxuvSD3DPC/Gy+U+sOA1LAuT8mkmRuvw+NACSaeXEQ+NHcVF7rONl6qcaxV3Uuemwawk+7+SJLw==",
        "dependencies": {
          "mime-types": "~2.1.34",
          "negotiator": "0.6.3"
        },
        "engines": {
          "node": ">= 0.6"
        }
      },
      "node_modules/array-flatten": {
        "version": "1.1.1",
        "resolved": "https://registry.npmjs.org/array-flatten/-/array-flatten-1.1.1.tgz",
        "integrity": "sha512-PCVAQswWemu6UdxsDFFX/+gVeYqKAod3D3UVm91jHwynguOwAvYPhx8nNlM++NqRcK6CxxpUafjmhIdKiHibqg=="
      },
      "node_modules/body-parser": {
        "version": "1.20.2",
        "resolved": "https://registry.npmjs.org/body-parser/-/body-parser-1.20.2.tgz",
        "integrity": "sha512-ml9pReCu3M61kGlqoTm2umSXTlRTuGTx0bfYj+uIUKKYycG5NtSbeetV3faSU6R7ajOPw0g/J1PvK4qNy7s5bA==",
        "dependencies": {
          "bytes": "3.1.2",
          "content-type": "~1.0.5",
          "debug": "2.6.9",
          "depd": "2.0.0",
          "destroy": "1.2.0",
          "http-errors": "2.0.0",
          "iconv-lite": "0.4.24",
          "on-finished": "2.4.1",
          "qs": "6.11.0",
          "raw-body": "2.5.2",
          "type-is": "~1.6.18",
          "unpipe": "1.0.0"
        },
        "engines": {
          "node": ">= 0.8",
          "npm": "1.2.8000 || >= 1.4.16"
        }
      },
      "node_modules/bson": {
        "version": "6.2.0",
        "resolved": "https://registry.npmjs.org/bson/-/bson-6.2.0.tgz",
        "integrity": "sha512-ID1cI+7bazPDyL9wYy9GaQ8gEEohWvcUl/Yf0dIdutJxnmInEEyCsb4awy/OiBfall7zBA179Pahi3vCdFze3Q==",
        "engines": {
          "node": ">=16.20.1"
        }
      },
      "node_modules/bytes": {
        "version": "3.1.2",
        "resolved": "https://registry.npmjs.org/bytes/-/bytes-3.1.2.tgz",
        "integrity": "sha512-/Nf7TyzTx6S3yRJObOAV7956r8cr2+Oj8AC5dt8wSP3BQAoeX58NoHyCU8P8zGkNXStjTSi6fzO6F0pBdcYbEg==",
        "engines": {
          "node": ">= 0.8"
        }
      },
      "node_modules/call-bind": {
        "version": "1.0.5",
        "resolved": "https://registry.npmjs.org/call-bind/-/call-bind-1.0.5.tgz",
        "integrity": "sha512-C3nQxfFZxFRVoJoGKKI8y3MOEo129NQ+FgQ08iye+Mk4zNZZGdjfs06bVTr+DBSlA66Q2VEcMki/cUCP4SercQ==",
        "dependencies": {
          "function-bind": "^1.1.2",
          "get-intrinsic": "^1.2.1",
          "set-function-length": "^1.1.1"
        },
        "funding": {
          "url": "https://github.com/sponsors/ljharb"
        }
      },
      "node_modules/content-disposition": {
        "version": "0.5.4",
        "resolved": "https://registry.npmjs.org/content-disposition/-/content-disposition-0.5.4.tgz",
        "integrity": "sha512-FveZTNuGw04cxlAiWbzi6zTAL/lhehaWbTtgluJh4/E95DqMwTmha3KZN1aAWA8cFIhHzMZUvLevkw5Rqk+tSQ==",
        "dependencies": {
          "safe-buffer": "5.2.1"
        },
        "engines": {
          "node": ">= 0.6"
        }
      },
      "node_modules/content-type": {
        "version": "1.0.5",
        "resolved": "https://registry.npmjs.org/content-type/-/content-type-1.0.5.tgz",
        "integrity": "sha512-nTjqfcBFEipKdXCv4YDQWCfmcLZKm81ldF0pAopTvyrFGVbcR6P/VAAd5G7N+0tTr8QqiU0tFadD6FK4NtJwOA==",
        "engines": {
          "node": ">= 0.6"
        }
      },
      "node_modules/cookie": {
        "version": "0.5.0",
        "resolved": "https://registry.npmjs.org/cookie/-/cookie-0.5.0.tgz",
        "integrity": "sha512-YZ3GUyn/o8gfKJlnlX7g7xq4gyO6OSuhGPKaaGssGB2qgDUS0gPgtTvoyZLTt9Ab6dC4hfc9dV5arkvc/OCmrw==",
        "engines": {
          "node": ">= 0.6"
        }
      },
      "node_modules/cookie-signature": {
        "version": "1.0.6",
        "resolved": "https://registry.npmjs.org/cookie-signature/-/cookie-signature-1.0.6.tgz",
        "integrity": "sha512-QADzlaHc8icV8I7vbaJXJwod9HWYp8uCqf1xa4OfNu1T7JVxQIrUgOWtHdNDtPiywmFbiS12VjotIXLrKM3orQ=="
      },
      "node_modules/cors": {
        "version": "2.8.5",
        "resolved": "https://registry.npmjs.org/cors/-/cors-2.8.5.tgz",
        "integrity": "sha512-KIHbLJqu73RGr/hnbrO9uBeixNGuvSQjul/jdFvS/KFSIH1hWVd1ng7zOHx+YrEfInLG7q4n6GHQ9cDtxv/P6g==",
        "dependencies": {
          "object-assign": "^4",
          "vary": "^1"
        },
        "engines": {
          "node": ">= 0.10"
        }
      },
      "node_modules/debug": {
        "version": "2.6.9",
        "resolved": "https://registry.npmjs.org/debug/-/debug-2.6.9.tgz",
        "integrity": "sha512-bC7ElrdJaJnPbAP+1EotYvqZsb3ecl5wi6Bfi6BJTUcNowp6cvspg0jXznRTKDjm/E7AdgFBVeAPVMNcKGsHMA==",
        "dependencies": {
          "ms": "2.0.0"
        }
      },
      "node_modules/define-data-property": {
        "version": "1.1.1",
        "resolved": "https://registry.npmjs.org/define-data-property/-/define-data-property-1.1.1.tgz",
        "integrity": "sha512-E7uGkTzkk1d0ByLeSc6ZsFS79Axg+m1P/VsgYsxHgiuc3tFSj+MjMIwe90FC4lOAZzNBdY7kkO2P2wKdsQ1vgQ==",
        "dependencies": {
          "get-intrinsic": "^1.2.1",
          "gopd": "^1.0.1",
          "has-property-descriptors": "^1.0.0"
        },
        "engines": {
          "node": ">= 0.4"
        }
      },
      "node_modules/depd": {
        "version": "2.0.0",
        "resolved": "https://registry.npmjs.org/depd/-/depd-2.0.0.tgz",
        "integrity": "sha512-g7nH6P6dyDioJogAAGprGpCtVImJhpPk/roCzdb3fIh61/s/nPsfR6onyMwkCAR/OlC3yBC0lESvUoQEAssIrw==",
        "engines": {
          "node": ">= 0.8"
        }
      },
      "node_modules/destroy": {
        "version": "1.2.0",
        "resolved": "https://registry.npmjs.org/destroy/-/destroy-1.2.0.tgz",
        "integrity": "sha512-2sJGJTaXIIaR1w4iJSNoN0hnMY7Gpc/n8D4qSCJw8QqFWXf7cuAgnEHxBpweaVcPevC2l3KpjYCx3NypQQgaJg==",
        "engines": {
          "node": ">= 0.8",
          "npm": "1.2.8000 || >= 1.4.16"
        }
      },
      "node_modules/ee-first": {
        "version": "1.1.1",
        "resolved": "https://registry.npmjs.org/ee-first/-/ee-first-1.1.1.tgz",
        "integrity": "sha512-WMwm9LhRUo+WUaRN+vRuETqG89IgZphVSNkdFgeb6sS/E4OrDIN7t48CAewSHXc6C8lefD8KKfr5vY61brQlow=="
      },
      "node_modules/encodeurl": {
        "version": "1.0.2",
        "resolved": "https://registry.npmjs.org/encodeurl/-/encodeurl-1.0.2.tgz",
        "integrity": "sha512-TPJXq8JqFaVYm2CWmPvnP2Iyo4ZSM7/QKcSmuMLDObfpH5fi7RUGmd/rTDf+rut/saiDiQEeVTNgAmJEdAOx0w==",
        "engines": {
          "node": ">= 0.8"
        }
      },
      "node_modules/escape-html": {
        "version": "1.0.3",
        "resolved": "https://registry.npmjs.org/escape-html/-/escape-html-1.0.3.tgz",
        "integrity": "sha512-NiSupZ4OeuGwr68lGIeym/ksIZMJodUGOSCZ/FSnTxcrekbvqrgdUxlJOMpijaKZVjAJrWrGs/6Jy8OMuyj9ow=="
      },
      "node_modules/etag": {
        "version": "1.8.1",
        "resolved": "https://registry.npmjs.org/etag/-/etag-1.8.1.tgz",
        "integrity": "sha512-aIL5Fx7mawVa300al2BnEE4iNvo1qETxLrPI/o05L7z6go7fCw1J6EQmbK4FmJ2AS7kgVF/KEZWufBfdClMcPg==",
        "engines": {
          "node": ">= 0.6"
        }
      },
      "node_modules/express": {
        "version": "4.18.2",
        "resolved": "https://registry.npmjs.org/express/-/express-4.18.2.tgz",
        "integrity": "sha512-5/PsL6iGPdfQ/lKM1UuielYgv3BUoJfz1aUwU9vHZ+J7gyvwdQXFEBIEIaxeGf0GIcreATNyBExtalisDbuMqQ==",
        "dependencies": {
          "accepts": "~1.3.8",
          "array-flatten": "1.1.1",
          "body-parser": "1.20.1",
          "content-disposition": "0.5.4",
          "content-type": "~1.0.4",
          "cookie": "0.5.0",
          "cookie-signature": "1.0.6",
          "debug": "2.6.9",
          "depd": "2.0.0",
          "encodeurl": "~1.0.2",
          "escape-html": "~1.0.3",
          "etag": "~1.8.1",
          "finalhandler": "1.2.0",
          "fresh": "0.5.2",
          "http-errors": "2.0.0",
          "merge-descriptors": "1.0.1",
          "methods": "~1.1.2",
          "on-finished": "2.4.1",
          "parseurl": "~1.3.3",
          "path-to-regexp": "0.1.7",
          "proxy-addr": "~2.0.7",
          "qs": "6.11.0",
          "range-parser": "~1.2.1",
          "safe-buffer": "5.2.1",
          "send": "0.18.0",
          "serve-static": "1.15.0",
          "setprototypeof": "1.2.0",
          "statuses": "2.0.1",
          "type-is": "~1.6.18",
          "utils-merge": "1.0.1",
          "vary": "~1.1.2"
        },
        "engines": {
          "node": ">= 0.10.0"
        }
      },
      "node_modules/express/node_modules/body-parser": {
        "version": "1.20.1",
        "resolved": "https://registry.npmjs.org/body-parser/-/body-parser-1.20.1.tgz",
        "integrity": "sha512-jWi7abTbYwajOytWCQc37VulmWiRae5RyTpaCyDcS5/lMdtwSz5lOpDE67srw/HYe35f1z3fDQw+3txg7gNtWw==",
        "dependencies": {
          "bytes": "3.1.2",
          "content-type": "~1.0.4",
          "debug": "2.6.9",
          "depd": "2.0.0",
          "destroy": "1.2.0",
          "http-errors": "2.0.0",
          "iconv-lite": "0.4.24",
          "on-finished": "2.4.1",
          "qs": "6.11.0",
          "raw-body": "2.5.1",
          "type-is": "~1.6.18",
          "unpipe": "1.0.0"
        },
        "engines": {
          "node": ">= 0.8",
          "npm": "1.2.8000 || >= 1.4.16"
        }
      },
      "node_modules/express/node_modules/raw-body": {
        "version": "2.5.1",
        "resolved": "https://registry.npmjs.org/raw-body/-/raw-body-2.5.1.tgz",
        "integrity": "sha512-qqJBtEyVgS0ZmPGdCFPWJ3FreoqvG4MVQln/kCgF7Olq95IbOp0/BWyMwbdtn4VTvkM8Y7khCQ2Xgk/tcrCXig==",
        "dependencies": {
          "bytes": "3.1.2",
          "http-errors": "2.0.0",
          "iconv-lite": "0.4.24",
          "unpipe": "1.0.0"
        },
        "engines": {
          "node": ">= 0.8"
        }
      },
      "node_modules/finalhandler": {
        "version": "1.2.0",
        "resolved": "https://registry.npmjs.org/finalhandler/-/finalhandler-1.2.0.tgz",
        "integrity": "sha512-5uXcUVftlQMFnWC9qu/svkWv3GTd2PfUhK/3PLkYNAe7FbqJMt3515HaxE6eRL74GdsriiwujiawdaB1BpEISg==",
        "dependencies": {
          "debug": "2.6.9",
          "encodeurl": "~1.0.2",
          "escape-html": "~1.0.3",
          "on-finished": "2.4.1",
          "parseurl": "~1.3.3",
          "statuses": "2.0.1",
          "unpipe": "~1.0.0"
        },
        "engines": {
          "node": ">= 0.8"
        }
      },
      "node_modules/forwarded": {
        "version": "0.2.0",
        "resolved": "https://registry.npmjs.org/forwarded/-/forwarded-0.2.0.tgz",
        "integrity": "sha512-buRG0fpBtRHSTCOASe6hD258tEubFoRLb4ZNA6NxMVHNw2gOcwHo9wyablzMzOA5z9xA9L1KNjk/Nt6MT9aYow==",
        "engines": {
          "node": ">= 0.6"
        }
      },
      "node_modules/fresh": {
        "version": "0.5.2",
        "resolved": "https://registry.npmjs.org/fresh/-/fresh-0.5.2.tgz",
        "integrity": "sha512-zJ2mQYM18rEFOudeV4GShTGIQ7RbzA7ozbU9I/XBpm7kqgMywgmylMwXHxZJmkVoYkna9d2pVXVXPdYTP9ej8Q==",
        "engines": {
          "node": ">= 0.6"
        }
      },
      "node_modules/function-bind": {
        "version": "1.1.2",
        "resolved": "https://registry.npmjs.org/function-bind/-/function-bind-1.1.2.tgz",
        "integrity": "sha512-7XHNxH7qX9xG5mIwxkhumTox/MIRNcOgDrxWsMt2pAr23WHp6MrRlN7FBSFpCpr+oVO0F744iUgR82nJMfG2SA==",
        "funding": {
          "url": "https://github.com/sponsors/ljharb"
        }
      },
      "node_modules/get-intrinsic": {
        "version": "1.2.2",
        "resolved": "https://registry.npmjs.org/get-intrinsic/-/get-intrinsic-1.2.2.tgz",
        "integrity": "sha512-0gSo4ml/0j98Y3lngkFEot/zhiCeWsbYIlZ+uZOVgzLyLaUw7wxUL+nCTP0XJvJg1AXulJRI3UJi8GsbDuxdGA==",
        "dependencies": {
          "function-bind": "^1.1.2",
          "has-proto": "^1.0.1",
          "has-symbols": "^1.0.3",
          "hasown": "^2.0.0"
        },
        "funding": {
          "url": "https://github.com/sponsors/ljharb"
        }
      },
      "node_modules/gopd": {
        "version": "1.0.1",
        "resolved": "https://registry.npmjs.org/gopd/-/gopd-1.0.1.tgz",
        "integrity": "sha512-d65bNlIadxvpb/A2abVdlqKqV563juRnZ1Wtk6s1sIR8uNsXR70xqIzVqxVf1eTqDunwT2MkczEeaezCKTZhwA==",
        "dependencies": {
          "get-intrinsic": "^1.1.3"
        },
        "funding": {
          "url": "https://github.com/sponsors/ljharb"
        }
      },
      "node_modules/has-property-descriptors": {
        "version": "1.0.1",
        "resolved": "https://registry.npmjs.org/has-property-descriptors/-/has-property-descriptors-1.0.1.tgz",
        "integrity": "sha512-VsX8eaIewvas0xnvinAe9bw4WfIeODpGYikiWYLH+dma0Jw6KHYqWiWfhQlgOVK8D6PvjubK5Uc4P0iIhIcNVg==",
        "dependencies": {
          "get-intrinsic": "^1.2.2"
        },
        "funding": {
          "url": "https://github.com/sponsors/ljharb"
        }
      },
      "node_modules/has-proto": {
        "version": "1.0.1",
        "resolved": "https://registry.npmjs.org/has-proto/-/has-proto-1.0.1.tgz",
        "integrity": "sha512-7qE+iP+O+bgF9clE5+UoBFzE65mlBiVj3tKCrlNQ0Ogwm0BjpT/gK4SlLYDMybDh5I3TCTKnPPa0oMG7JDYrhg==",
        "engines": {
          "node": ">= 0.4"
        },
        "funding": {
          "url": "https://github.com/sponsors/ljharb"
        }
      },
      "node_modules/has-symbols": {
        "version": "1.0.3",
        "resolved": "https://registry.npmjs.org/has-symbols/-/has-symbols-1.0.3.tgz",
        "integrity": "sha512-l3LCuF6MgDNwTDKkdYGEihYjt5pRPbEg46rtlmnSPlUbgmB8LOIrKJbYYFBSbnPaJexMKtiPO8hmeRjRz2Td+A==",
        "engines": {
          "node": ">= 0.4"
        },
        "funding": {
          "url": "https://github.com/sponsors/ljharb"
        }
      },
      "node_modules/hasown": {
        "version": "2.0.0",
        "resolved": "https://registry.npmjs.org/hasown/-/hasown-2.0.0.tgz",
        "integrity": "sha512-vUptKVTpIJhcczKBbgnS+RtcuYMB8+oNzPK2/Hp3hanz8JmpATdmmgLgSaadVREkDm+e2giHwY3ZRkyjSIDDFA==",
        "dependencies": {
          "function-bind": "^1.1.2"
        },
        "engines": {
          "node": ">= 0.4"
        }
      },
      "node_modules/http-errors": {
        "version": "2.0.0",
        "resolved": "https://registry.npmjs.org/http-errors/-/http-errors-2.0.0.tgz",
        "integrity": "sha512-FtwrG/euBzaEjYeRqOgly7G0qviiXoJWnvEH2Z1plBdXgbyjv34pHTSb9zoeHMyDy33+DWy5Wt9Wo+TURtOYSQ==",
        "dependencies": {
          "depd": "2.0.0",
          "inherits": "2.0.4",
          "setprototypeof": "1.2.0",
          "statuses": "2.0.1",
          "toidentifier": "1.0.1"
        },
        "engines": {
          "node": ">= 0.8"
        }
      },
      "node_modules/iconv-lite": {
        "version": "0.4.24",
        "resolved": "https://registry.npmjs.org/iconv-lite/-/iconv-lite-0.4.24.tgz",
        "integrity": "sha512-v3MXnZAcvnywkTUEZomIActle7RXXeedOR31wwl7VlyoXO4Qi9arvSenNQWne1TcRwhCL1HwLI21bEqdpj8/rA==",
        "dependencies": {
          "safer-buffer": ">= 2.1.2 < 3"
        },
        "engines": {
          "node": ">=0.10.0"
        }
      },
      "node_modules/inherits": {
        "version": "2.0.4",
        "resolved": "https://registry.npmjs.org/inherits/-/inherits-2.0.4.tgz",
        "integrity": "sha512-k/vGaX4/Yla3WzyMCvTQOXYeIHvqOKtnqBduzTHpzpQZzAskKMhZ2K+EnBiSM9zGSoIFeMpXKxa4dYeZIQqewQ=="
      },
      "node_modules/ipaddr.js": {
        "version": "1.9.1",
        "resolved": "https://registry.npmjs.org/ipaddr.js/-/ipaddr.js-1.9.1.tgz",
        "integrity": "sha512-0KI/607xoxSToH7GjN1FfSbLoU0+btTicjsQSWQlh/hZykN8KpmMf7uYwPW3R+akZ6R/w18ZlXSHBYXiYUPO3g==",
        "engines": {
          "node": ">= 0.10"
        }
      },
      "node_modules/kareem": {
        "version": "2.5.1",
        "resolved": "https://registry.npmjs.org/kareem/-/kareem-2.5.1.tgz",
        "integrity": "sha512-7jFxRVm+jD+rkq3kY0iZDJfsO2/t4BBPeEb2qKn2lR/9KhuksYk5hxzfRYWMPV8P/x2d0kHD306YyWLzjjH+uA==",
        "engines": {
          "node": ">=12.0.0"
        }
      },
      "node_modules/media-typer": {
        "version": "0.3.0",
        "resolved": "https://registry.npmjs.org/media-typer/-/media-typer-0.3.0.tgz",
        "integrity": "sha512-dq+qelQ9akHpcOl/gUVRTxVIOkAJ1wR3QAvb4RsVjS8oVoFjDGTc679wJYmUmknUF5HwMLOgb5O+a3KxfWapPQ==",
        "engines": {
          "node": ">= 0.6"
        }
      },
      "node_modules/memory-pager": {
        "version": "1.5.0",
        "resolved": "https://registry.npmjs.org/memory-pager/-/memory-pager-1.5.0.tgz",
        "integrity": "sha512-ZS4Bp4r/Zoeq6+NLJpP+0Zzm0pR8whtGPf1XExKLJBAczGMnSi3It14OiNCStjQjM6NU1okjQGSxgEZN8eBYKg=="
      },
      "node_modules/merge-descriptors": {
        "version": "1.0.1",
        "resolved": "https://registry.npmjs.org/merge-descriptors/-/merge-descriptors-1.0.1.tgz",
        "integrity": "sha512-cCi6g3/Zr1iqQi6ySbseM1Xvooa98N0w31jzUYrXPX2xqObmFGHJ0tQ5u74H3mVh7wLouTseZyYIq39g8cNp1w=="
      },
      "node_modules/methods": {
        "version": "1.1.2",
        "resolved": "https://registry.npmjs.org/methods/-/methods-1.1.2.tgz",
        "integrity": "sha512-iclAHeNqNm68zFtnZ0e+1L2yUIdvzNoauKU4WBA3VvH/vPFieF7qfRlwUZU+DA9P9bPXIS90ulxoUoCH23sV2w==",
        "engines": {
          "node": ">= 0.6"
        }
      },
      "node_modules/mime": {
        "version": "1.6.0",
        "resolved": "https://registry.npmjs.org/mime/-/mime-1.6.0.tgz",
        "integrity": "sha512-x0Vn8spI+wuJ1O6S7gnbaQg8Pxh4NNHb7KSINmEWKiPE4RKOplvijn+NkmYmmRgP68mc70j2EbeTFRsrswaQeg==",
        "bin": {
          "mime": "cli.js"
        },
        "engines": {
          "node": ">=4"
        }
      },
      "node_modules/mime-db": {
        "version": "1.52.0",
        "resolved": "https://registry.npmjs.org/mime-db/-/mime-db-1.52.0.tgz",
        "integrity": "sha512-sPU4uV7dYlvtWJxwwxHD0PuihVNiE7TyAbQ5SWxDCB9mUYvOgroQOwYQQOKPJ8CIbE+1ETVlOoK1UC2nU3gYvg==",
        "engines": {
          "node": ">= 0.6"
        }
      },
      "node_modules/mime-types": {
        "version": "2.1.35",
        "resolved": "https://registry.npmjs.org/mime-types/-/mime-types-2.1.35.tgz",
        "integrity": "sha512-ZDY+bPm5zTTF+YpCrAU9nK0UgICYPT0QtT1NZWFv4s++TNkcgVaT0g6+4R2uI4MjQjzysHB1zxuWL50hzaeXiw==",
        "dependencies": {
          "mime-db": "1.52.0"
        },
        "engines": {
          "node": ">= 0.6"
        }
      },
      "node_modules/mongodb": {
        "version": "6.2.0",
        "resolved": "https://registry.npmjs.org/mongodb/-/mongodb-6.2.0.tgz",
        "integrity": "sha512-d7OSuGjGWDZ5usZPqfvb36laQ9CPhnWkAGHT61x5P95p/8nMVeH8asloMwW6GcYFeB0Vj4CB/1wOTDG2RA9BFA==",
        "dependencies": {
          "@mongodb-js/saslprep": "^1.1.0",
          "bson": "^6.2.0",
          "mongodb-connection-string-url": "^2.6.0"
        },
        "engines": {
          "node": ">=16.20.1"
        },
        "peerDependencies": {
          "@aws-sdk/credential-providers": "^3.188.0",
          "@mongodb-js/zstd": "^1.1.0",
          "gcp-metadata": "^5.2.0",
          "kerberos": "^2.0.1",
          "mongodb-client-encryption": ">=6.0.0 <7",
          "snappy": "^7.2.2",
          "socks": "^2.7.1"
        },
        "peerDependenciesMeta": {
          "@aws-sdk/credential-providers": {
            "optional": true
          },
          "@mongodb-js/zstd": {
            "optional": true
          },
          "gcp-metadata": {
            "optional": true
          },
          "kerberos": {
            "optional": true
          },
          "mongodb-client-encryption": {
            "optional": true
          },
          "snappy": {
            "optional": true
          },
          "socks": {
            "optional": true
          }
        }
      },
      "node_modules/mongodb-connection-string-url": {
        "version": "2.6.0",
        "resolved": "https://registry.npmjs.org/mongodb-connection-string-url/-/mongodb-connection-string-url-2.6.0.tgz",
        "integrity": "sha512-WvTZlI9ab0QYtTYnuMLgobULWhokRjtC7db9LtcVfJ+Hsnyr5eo6ZtNAt3Ly24XZScGMelOcGtm7lSn0332tPQ==",
        "dependencies": {
          "@types/whatwg-url": "^8.2.1",
          "whatwg-url": "^11.0.0"
        }
      },
      "node_modules/mongoose": {
        "version": "8.0.3",
        "resolved": "https://registry.npmjs.org/mongoose/-/mongoose-8.0.3.tgz",
        "integrity": "sha512-LJRT0yP4TW14HT4r2RkxqyvoTylMSzWpl5QOeVHTnRggCLQSpkoBdgbUtORFq/mSL2o9cLCPJz+6uzFj25qbHw==",
        "dependencies": {
          "bson": "^6.2.0",
          "kareem": "2.5.1",
          "mongodb": "6.2.0",
          "mpath": "0.9.0",
          "mquery": "5.0.0",
          "ms": "2.1.3",
          "sift": "16.0.1"
        },
        "engines": {
          "node": ">=16.20.1"
        },
        "funding": {
          "type": "opencollective",
          "url": "https://opencollective.com/mongoose"
        }
      },
      "node_modules/mongoose/node_modules/ms": {
        "version": "2.1.3",
        "resolved": "https://registry.npmjs.org/ms/-/ms-2.1.3.tgz",
        "integrity": "sha512-6FlzubTLZG3J2a/NVCAleEhjzq5oxgHyaCU9yYXvcLsvoVaHJq/s5xXI6/XXP6tz7R9xAOtHnSO/tXtF3WRTlA=="
      },
      "node_modules/mpath": {
        "version": "0.9.0",
        "resolved": "https://registry.npmjs.org/mpath/-/mpath-0.9.0.tgz",
        "integrity": "sha512-ikJRQTk8hw5DEoFVxHG1Gn9T/xcjtdnOKIU1JTmGjZZlg9LST2mBLmcX3/ICIbgJydT2GOc15RnNy5mHmzfSew==",
        "engines": {
          "node": ">=4.0.0"
        }
      },
      "node_modules/mquery": {
        "version": "5.0.0",
        "resolved": "https://registry.npmjs.org/mquery/-/mquery-5.0.0.tgz",
        "integrity": "sha512-iQMncpmEK8R8ncT8HJGsGc9Dsp8xcgYMVSbs5jgnm1lFHTZqMJTUWTDx1LBO8+mK3tPNZWFLBghQEIOULSTHZg==",
        "dependencies": {
          "debug": "4.x"
        },
        "engines": {
          "node": ">=14.0.0"
        }
      },
      "node_modules/mquery/node_modules/debug": {
        "version": "4.3.4",
        "resolved": "https://registry.npmjs.org/debug/-/debug-4.3.4.tgz",
        "integrity": "sha512-PRWFHuSU3eDtQJPvnNY7Jcket1j0t5OuOsFzPPzsekD52Zl8qUfFIPEiswXqIvHWGVHOgX+7G/vCNNhehwxfkQ==",
        "dependencies": {
          "ms": "2.1.2"
        },
        "engines": {
          "node": ">=6.0"
        },
        "peerDependenciesMeta": {
          "supports-color": {
            "optional": true
          }
        }
      },
      "node_modules/mquery/node_modules/ms": {
        "version": "2.1.2",
        "resolved": "https://registry.npmjs.org/ms/-/ms-2.1.2.tgz",
        "integrity": "sha512-sGkPx+VjMtmA6MX27oA4FBFELFCZZ4S4XqeGOXCv68tT+jb3vk/RyaKWP0PTKyWtmLSM0b+adUTEvbs1PEaH2w=="
      },
      "node_modules/ms": {
        "version": "2.0.0",
        "resolved": "https://registry.npmjs.org/ms/-/ms-2.0.0.tgz",
        "integrity": "sha512-Tpp60P6IUJDTuOq/5Z8cdskzJujfwqfOTkrwIwj7IRISpnkJnT6SyJ4PCPnGMoFjC9ddhal5KVIYtAt97ix05A=="
      },
      "node_modules/negotiator": {
        "version": "0.6.3",
        "resolved": "https://registry.npmjs.org/negotiator/-/negotiator-0.6.3.tgz",
        "integrity": "sha512-+EUsqGPLsM+j/zdChZjsnX51g4XrHFOIXwfnCVPGlQk/k5giakcKsuxCObBRu6DSm9opw/O6slWbJdghQM4bBg==",
        "engines": {
          "node": ">= 0.6"
        }
      },
      "node_modules/object-assign": {
        "version": "4.1.1",
        "resolved": "https://registry.npmjs.org/object-assign/-/object-assign-4.1.1.tgz",
        "integrity": "sha512-rJgTQnkUnH1sFw8yT6VSU3zD3sWmu6sZhIseY8VX+GRu3P6F7Fu+JNDoXfklElbLJSnc3FUQHVe4cU5hj+BcUg==",
        "engines": {
          "node": ">=0.10.0"
        }
      },
      "node_modules/object-inspect": {
        "version": "1.13.1",
        "resolved": "https://registry.npmjs.org/object-inspect/-/object-inspect-1.13.1.tgz",
        "integrity": "sha512-5qoj1RUiKOMsCCNLV1CBiPYE10sziTsnmNxkAI/rZhiD63CF7IqdFGC/XzjWjpSgLf0LxXX3bDFIh0E18f6UhQ==",
        "funding": {
          "url": "https://github.com/sponsors/ljharb"
        }
      },
      "node_modules/on-finished": {
        "version": "2.4.1",
        "resolved": "https://registry.npmjs.org/on-finished/-/on-finished-2.4.1.tgz",
        "integrity": "sha512-oVlzkg3ENAhCk2zdv7IJwd/QUD4z2RxRwpkcGY8psCVcCYZNq4wYnVWALHM+brtuJjePWiYF/ClmuDr8Ch5+kg==",
        "dependencies": {
          "ee-first": "1.1.1"
        },
        "engines": {
          "node": ">= 0.8"
        }
      },
      "node_modules/parseurl": {
        "version": "1.3.3",
        "resolved": "https://registry.npmjs.org/parseurl/-/parseurl-1.3.3.tgz",
        "integrity": "sha512-CiyeOxFT/JZyN5m0z9PfXw4SCBJ6Sygz1Dpl0wqjlhDEGGBP1GnsUVEL0p63hoG1fcj3fHynXi9NYO4nWOL+qQ==",
        "engines": {
          "node": ">= 0.8"
        }
      },
      "node_modules/path-to-regexp": {
        "version": "0.1.7",
        "resolved": "https://registry.npmjs.org/path-to-regexp/-/path-to-regexp-0.1.7.tgz",
        "integrity": "sha512-5DFkuoqlv1uYQKxy8omFBeJPQcdoE07Kv2sferDCrAq1ohOU+MSDswDIbnx3YAM60qIOnYa53wBhXW0EbMonrQ=="
      },
      "node_modules/proxy-addr": {
        "version": "2.0.7",
        "resolved": "https://registry.npmjs.org/proxy-addr/-/proxy-addr-2.0.7.tgz",
        "integrity": "sha512-llQsMLSUDUPT44jdrU/O37qlnifitDP+ZwrmmZcoSKyLKvtZxpyV0n2/bD/N4tBAAZ/gJEdZU7KMraoK1+XYAg==",
        "dependencies": {
          "forwarded": "0.2.0",
          "ipaddr.js": "1.9.1"
        },
        "engines": {
          "node": ">= 0.10"
        }
      },
      "node_modules/punycode": {
        "version": "2.3.1",
        "resolved": "https://registry.npmjs.org/punycode/-/punycode-2.3.1.tgz",
        "integrity": "sha512-vYt7UD1U9Wg6138shLtLOvdAu+8DsC/ilFtEVHcH+wydcSpNE20AfSOduf6MkRFahL5FY7X1oU7nKVZFtfq8Fg==",
        "engines": {
          "node": ">=6"
        }
      },
      "node_modules/qs": {
        "version": "6.11.0",
        "resolved": "https://registry.npmjs.org/qs/-/qs-6.11.0.tgz",
        "integrity": "sha512-MvjoMCJwEarSbUYk5O+nmoSzSutSsTwF85zcHPQ9OrlFoZOYIjaqBAJIqIXjptyD5vThxGq52Xu/MaJzRkIk4Q==",
        "dependencies": {
          "side-channel": "^1.0.4"
        },
        "engines": {
          "node": ">=0.6"
        },
        "funding": {
          "url": "https://github.com/sponsors/ljharb"
        }
      },
      "node_modules/range-parser": {
        "version": "1.2.1",
        "resolved": "https://registry.npmjs.org/range-parser/-/range-parser-1.2.1.tgz",
        "integrity": "sha512-Hrgsx+orqoygnmhFbKaHE6c296J+HTAQXoxEF6gNupROmmGJRoyzfG3ccAveqCBrwr/2yxQ5BVd/GTl5agOwSg==",
        "engines": {
          "node": ">= 0.6"
        }
      },
      "node_modules/raw-body": {
        "version": "2.5.2",
        "resolved": "https://registry.npmjs.org/raw-body/-/raw-body-2.5.2.tgz",
        "integrity": "sha512-8zGqypfENjCIqGhgXToC8aB2r7YrBX+AQAfIPs/Mlk+BtPTztOvTS01NRW/3Eh60J+a48lt8qsCzirQ6loCVfA==",
        "dependencies": {
          "bytes": "3.1.2",
          "http-errors": "2.0.0",
          "iconv-lite": "0.4.24",
          "unpipe": "1.0.0"
        },
        "engines": {
          "node": ">= 0.8"
        }
      },
      "node_modules/safe-buffer": {
        "version": "5.2.1",
        "resolved": "https://registry.npmjs.org/safe-buffer/-/safe-buffer-5.2.1.tgz",
        "integrity": "sha512-rp3So07KcdmmKbGvgaNxQSJr7bGVSVk5S9Eq1F+ppbRo70+YeaDxkw5Dd8NPN+GD6bjnYm2VuPuCXmpuYvmCXQ==",
        "funding": [
          {
            "type": "github",
            "url": "https://github.com/sponsors/feross"
          },
          {
            "type": "patreon",
            "url": "https://www.patreon.com/feross"
          },
          {
            "type": "consulting",
            "url": "https://feross.org/support"
          }
        ]
      },
      "node_modules/safer-buffer": {
        "version": "2.1.2",
        "resolved": "https://registry.npmjs.org/safer-buffer/-/safer-buffer-2.1.2.tgz",
        "integrity": "sha512-YZo3K82SD7Riyi0E1EQPojLz7kpepnSQI9IyPbHHg1XXXevb5dJI7tpyN2ADxGcQbHG7vcyRHk0cbwqcQriUtg=="
      },
      "node_modules/send": {
        "version": "0.18.0",
        "resolved": "https://registry.npmjs.org/send/-/send-0.18.0.tgz",
        "integrity": "sha512-qqWzuOjSFOuqPjFe4NOsMLafToQQwBSOEpS+FwEt3A2V3vKubTquT3vmLTQpFgMXp8AlFWFuP1qKaJZOtPpVXg==",
        "dependencies": {
          "debug": "2.6.9",
          "depd": "2.0.0",
          "destroy": "1.2.0",
          "encodeurl": "~1.0.2",
          "escape-html": "~1.0.3",
          "etag": "~1.8.1",
          "fresh": "0.5.2",
          "http-errors": "2.0.0",
          "mime": "1.6.0",
          "ms": "2.1.3",
          "on-finished": "2.4.1",
          "range-parser": "~1.2.1",
          "statuses": "2.0.1"
        },
        "engines": {
          "node": ">= 0.8.0"
        }
      },
      "node_modules/send/node_modules/ms": {
        "version": "2.1.3",
        "resolved": "https://registry.npmjs.org/ms/-/ms-2.1.3.tgz",
        "integrity": "sha512-6FlzubTLZG3J2a/NVCAleEhjzq5oxgHyaCU9yYXvcLsvoVaHJq/s5xXI6/XXP6tz7R9xAOtHnSO/tXtF3WRTlA=="
      },
      "node_modules/serve-static": {
        "version": "1.15.0",
        "resolved": "https://registry.npmjs.org/serve-static/-/serve-static-1.15.0.tgz",
        "integrity": "sha512-XGuRDNjXUijsUL0vl6nSD7cwURuzEgglbOaFuZM9g3kwDXOWVTck0jLzjPzGD+TazWbboZYu52/9/XPdUgne9g==",
        "dependencies": {
          "encodeurl": "~1.0.2",
          "escape-html": "~1.0.3",
          "parseurl": "~1.3.3",
          "send": "0.18.0"
        },
        "engines": {
          "node": ">= 0.8.0"
        }
      },
      "node_modules/set-function-length": {
        "version": "1.1.1",
        "resolved": "https://registry.npmjs.org/set-function-length/-/set-function-length-1.1.1.tgz",
        "integrity": "sha512-VoaqjbBJKiWtg4yRcKBQ7g7wnGnLV3M8oLvVWwOk2PdYY6PEFegR1vezXR0tw6fZGF9csVakIRjrJiy2veSBFQ==",
        "dependencies": {
          "define-data-property": "^1.1.1",
          "get-intrinsic": "^1.2.1",
          "gopd": "^1.0.1",
          "has-property-descriptors": "^1.0.0"
        },
        "engines": {
          "node": ">= 0.4"
        }
      },
      "node_modules/setprototypeof": {
        "version": "1.2.0",
        "resolved": "https://registry.npmjs.org/setprototypeof/-/setprototypeof-1.2.0.tgz",
        "integrity": "sha512-E5LDX7Wrp85Kil5bhZv46j8jOeboKq5JMmYM3gVGdGH8xFpPWXUMsNrlODCrkoxMEeNi/XZIwuRvY4XNwYMJpw=="
      },
      "node_modules/side-channel": {
        "version": "1.0.4",
        "resolved": "https://registry.npmjs.org/side-channel/-/side-channel-1.0.4.tgz",
        "integrity": "sha512-q5XPytqFEIKHkGdiMIrY10mvLRvnQh42/+GoBlFW3b2LXLE2xxJpZFdm94we0BaoV3RwJyGqg5wS7epxTv0Zvw==",
        "dependencies": {
          "call-bind": "^1.0.0",
          "get-intrinsic": "^1.0.2",
          "object-inspect": "^1.9.0"
        },
        "funding": {
          "url": "https://github.com/sponsors/ljharb"
        }
      },
      "node_modules/sift": {
        "version": "16.0.1",
        "resolved": "https://registry.npmjs.org/sift/-/sift-16.0.1.tgz",
        "integrity": "sha512-Wv6BjQ5zbhW7VFefWusVP33T/EM0vYikCaQ2qR8yULbsilAT8/wQaXvuQ3ptGLpoKx+lihJE3y2UTgKDyyNHZQ=="
      },
      "node_modules/sparse-bitfield": {
        "version": "3.0.3",
        "resolved": "https://registry.npmjs.org/sparse-bitfield/-/sparse-bitfield-3.0.3.tgz",
        "integrity": "sha512-kvzhi7vqKTfkh0PZU+2D2PIllw2ymqJKujUcyPMd9Y75Nv4nPbGJZXNhxsgdQab2BmlDct1YnfQCguEvHr7VsQ==",
        "dependencies": {
          "memory-pager": "^1.0.2"
        }
      },
      "node_modules/statuses": {
        "version": "2.0.1",
        "resolved": "https://registry.npmjs.org/statuses/-/statuses-2.0.1.tgz",
        "integrity": "sha512-RwNA9Z/7PrK06rYLIzFMlaF+l73iwpzsqRIFgbMLbTcLD6cOao82TaWefPXQvB2fOC4AjuYSEndS7N/mTCbkdQ==",
        "engines": {
          "node": ">= 0.8"
        }
      },
      "node_modules/toidentifier": {
        "version": "1.0.1",
        "resolved": "https://registry.npmjs.org/toidentifier/-/toidentifier-1.0.1.tgz",
        "integrity": "sha512-o5sSPKEkg/DIQNmH43V0/uerLrpzVedkUh8tGNvaeXpfpuwjKenlSox/2O/BTlZUtEe+JG7s5YhEz608PlAHRA==",
        "engines": {
          "node": ">=0.6"
        }
      },
      "node_modules/tr46": {
        "version": "3.0.0",
        "resolved": "https://registry.npmjs.org/tr46/-/tr46-3.0.0.tgz",
        "integrity": "sha512-l7FvfAHlcmulp8kr+flpQZmVwtu7nfRV7NZujtN0OqES8EL4O4e0qqzL0DC5gAvx/ZC/9lk6rhcUwYvkBnBnYA==",
        "dependencies": {
          "punycode": "^2.1.1"
        },
        "engines": {
          "node": ">=12"
        }
      },
      "node_modules/type-is": {
        "version": "1.6.18",
        "resolved": "https://registry.npmjs.org/type-is/-/type-is-1.6.18.tgz",
        "integrity": "sha512-TkRKr9sUTxEH8MdfuCSP7VizJyzRNMjj2J2do2Jr3Kym598JVdEksuzPQCnlFPW4ky9Q+iA+ma9BGm06XQBy8g==",
        "dependencies": {
          "media-typer": "0.3.0",
          "mime-types": "~2.1.24"
        },
        "engines": {
          "node": ">= 0.6"
        }
      },
      "node_modules/undici-types": {
        "version": "5.26.5",
        "resolved": "https://registry.npmjs.org/undici-types/-/undici-types-5.26.5.tgz",
        "integrity": "sha512-JlCMO+ehdEIKqlFxk6IfVoAUVmgz7cU7zD/h9XZ0qzeosSHmUJVOzSQvvYSYWXkFXC+IfLKSIffhv0sVZup6pA=="
      },
      "node_modules/unpipe": {
        "version": "1.0.0",
        "resolved": "https://registry.npmjs.org/unpipe/-/unpipe-1.0.0.tgz",
        "integrity": "sha512-pjy2bYhSsufwWlKwPc+l3cN7+wuJlK6uz0YdJEOlQDbl6jo/YlPi4mb8agUkVC8BF7V8NuzeyPNqRksA3hztKQ==",
        "engines": {
          "node": ">= 0.8"
        }
      },
      "node_modules/utils-merge": {
        "version": "1.0.1",
        "resolved": "https://registry.npmjs.org/utils-merge/-/utils-merge-1.0.1.tgz",
        "integrity": "sha512-pMZTvIkT1d+TFGvDOqodOclx0QWkkgi6Tdoa8gC8ffGAAqz9pzPTZWAybbsHHoED/ztMtkv/VoYTYyShUn81hA==",
        "engines": {
          "node": ">= 0.4.0"
        }
      },
      "node_modules/vary": {
        "version": "1.1.2",
        "resolved": "https://registry.npmjs.org/vary/-/vary-1.1.2.tgz",
        "integrity": "sha512-BNGbWLfd0eUPabhkXUVm0j8uuvREyTh5ovRa/dyow/BqAbZJyC+5fU+IzQOzmAKzYqYRAISoRhdQr3eIZ/PXqg==",
        "engines": {
          "node": ">= 0.8"
        }
      },
      "node_modules/webidl-conversions": {
        "version": "7.0.0",
        "resolved": "https://registry.npmjs.org/webidl-conversions/-/webidl-conversions-7.0.0.tgz",
        "integrity": "sha512-VwddBukDzu71offAQR975unBIGqfKZpM+8ZX6ySk8nYhVoo5CYaZyzt3YBvYtRtO+aoGlqxPg/B87NGVZ/fu6g==",
        "engines": {
          "node": ">=12"
        }
      },
      "node_modules/whatwg-url": {
        "version": "11.0.0",
        "resolved": "https://registry.npmjs.org/whatwg-url/-/whatwg-url-11.0.0.tgz",
        "integrity": "sha512-RKT8HExMpoYx4igMiVMY83lN6UeITKJlBQ+vR/8ZJ8OCdSiN3RwCq+9gH0+Xzj0+5IrM6i4j/6LuvzbZIQgEcQ==",
        "dependencies": {
          "tr46": "^3.0.0",
          "webidl-conversions": "^7.0.0"
        },
        "engines": {
          "node": ">=12"
        }
      }
    }
  }
  